# Power BI Data Model (Star Schema) — Supply Chain Risk

Import these CSVs into Power BI Desktop (Get Data > Text/CSV) and build relationships.

## Tables
- **fact_purchase_orders_scored** (grain: 1 row / PO, with late_probability + risk_score) — central fact
- **fact_disruptions** (grain: 1 row / disruption event)
- **fact_inventory_buffer** (grain: 1 row / plant-product SKU) — inventory bottlenecks
- **dim_suppliers** / **dim_products** / **dim_plants** — descriptive dimensions
- **dim_risk_level** — risk tiers, SLA, escalation action
- **kpi_measures** — pre-computed KPI card values

## ⭐ DAX measures
A complete set of production DAX measures is in **`MEASURES.dax`** (delivery, risk, supplier,
disruption, and inventory KPIs + traffic-light status). Paste them via Modeling > New Measure.

## Relationships
| From (fact) | To (dim) | Cardinality |
|---|---|---|
| fact_purchase_orders_scored[supplier_id] | dim_suppliers[supplier_id] | Many-to-One |
| fact_purchase_orders_scored[product_id]  | dim_products[product_id]   | Many-to-One |
| fact_purchase_orders_scored[plant_id]    | dim_plants[plant_id]       | Many-to-One |
| fact_purchase_orders_scored[risk_level]  | dim_risk_level[risk_level_key] | Many-to-One |
| fact_disruptions[supplier_id]            | dim_suppliers[supplier_id] | Many-to-One |
| fact_inventory_buffer[plant_id]          | dim_plants[plant_id]       | Many-to-One |
| fact_inventory_buffer[product_id]        | dim_products[product_id]   | Many-to-One |

## Suggested DAX
```
Late Orders = SUM(fact_purchase_orders_scored[is_late])
Late Rate % = DIVIDE([Late Orders], COUNTROWS(fact_purchase_orders_scored)) * 100
High Risk POs = CALCULATE(COUNTROWS(fact_purchase_orders_scored), fact_purchase_orders_scored[risk_score] >= 50)
Total PO Value = SUM(fact_purchase_orders_scored[total_value_usd])
Disruption Loss = SUM(fact_disruptions[financial_loss_usd])
Recommended Threshold = 0.23
```

## Suggested visuals
1. KPI cards: Late Rate %, High Risk POs, Disruption Loss, Total PO Value
2. Bar: Late Rate % by dim_suppliers[category]
3. Stacked bar: disruptions by type & severity
4. Map: suppliers by dim_suppliers[country_name] colored by risk_band
5. Table: top suppliers by avg_risk with conditional formatting
6. Line: Late Rate % over fiscal_year
