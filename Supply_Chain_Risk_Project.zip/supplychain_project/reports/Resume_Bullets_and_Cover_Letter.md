# Supply Chain Risk Project — Résumé Bullets & Cover-Letter Paragraphs

> Copy-paste ready. Role-targeted variants + cover-letter paragraphs in three tones.
> Built from the actual project: 3,000 POs · 120 suppliers · 200 disruptions · $479M tracked loss.

---

## 🎯 Variant 1 — DATA ANALYST roles  ⭐ (closest match to your resume bullets)
**Supply Chain Risk & Disruption Analytics** — *SQL, Pandas, Power BI (DAX)*

- Improved operational visibility by analyzing supply-chain records in **SQL (DuckDB) and Pandas** to expose **shipment delays, supplier risks, and inventory bottlenecks** — surfacing 17 understocked SKUs (9 critical) and the highest-risk suppliers by late-rate.
- Raised KPI-tracking efficiency by designing **interactive Power BI dashboards with 30+ DAX measures** enabling live monitoring of logistics performance (late rate, value-at-risk, inventory health, disruption loss).
- Reduced manual reporting effort by consolidating **Excel and Power BI pipelines** into one automated flow (cleaning → SQL/Pandas analysis → scored outputs → multi-sheet Excel + dashboard), enabling same-day decisions from structured insights.
- Quantified **$479M in disruption-driven loss** and a **28% late-delivery rate** across 3,000 POs, 120 suppliers and 200 disruption events, delivering a supplier watch-list and 17 visualizations.

> These four lines map directly to your three resume bullets (SQL+Pandas analysis of delays/supplier-risk/inventory; Power BI DAX dashboards; consolidated Excel+Power BI pipelines for same-day decisions).

## 🎯 Variant 2 — SUPPLY CHAIN / OPERATIONS ANALYST roles
**Supplier Risk Scoring & Late-Delivery Prediction** — *Python, Scikit-learn, Power BI*

- Engineered an end-to-end supplier-risk pipeline that scored **3,000 purchase orders**, combining **anomaly detection (Isolation Forest)** and **classification (Random Forest)** to predict late deliveries and rank suppliers by risk.
- Designed a **composite risk score (0–100)** and four-tier escalation model (Critical → activate backup supplier; High → expedite review, SLA 24h) to prioritize procurement intervention.
- Applied **cost-based threshold tuning** (late-delivery cost vs. intervention cost) to minimize expected disruption cost while capturing ~97% of late deliveries.
- Delivered a **Power BI star-schema data model** and interactive dashboard giving procurement near-real-time visibility into supplier and disruption risk.

## 🎯 Variant 3 — DATA SCIENTIST / ML roles
**End-to-End Supply Chain Risk ML Pipeline** — *Python, Scikit-learn*

- Built an ML pipeline over a 5-fact / 3-dimension star schema, engineering **26+ features** from supplier scorecards, disruption history, network dependencies and order attributes.
- Paired **unsupervised Isolation Forest** with a **supervised Random Forest** classifier, handling class imbalance with stratified splits and balanced class weights.
- Evaluated with **ROC-AUC, precision-recall, F1 and confusion matrices**, and rigorously **excluded target-leakage features** (post-hoc delay) to keep the model genuinely predictive.
- Implemented **cost-sensitive threshold optimization** and persisted models with joblib for batch scoring; shipped results via dashboard and Power BI dataset.

---

## ✉️ Cover-Letter — Professional & Confident
> In my recent supply-chain analytics work, I built an end-to-end pipeline that scored 3,000 purchase
> orders across 120 suppliers by pairing anomaly detection with supervised classification in Python and
> Scikit-learn, then surfaced the results through Power BI dashboards and tiered KPI alerts. The system
> quantified nearly half a billion dollars in disruption-driven loss and flagged the highest-risk orders
> for proactive intervention. I'm excited to bring that same blend of rigorous modeling and clear,
> decision-ready reporting to your team.

## ✉️ Cover-Letter — Warm & Enthusiastic
> I love turning tangled operational data into decisions teams can act on. On a recent project I built a
> supply-chain risk pipeline that scored thousands of purchase orders, ranked suppliers by risk, and
> wrapped everything in Power BI dashboards and alerts so procurement could intervene before a late
> delivery became a line-down event. The chance to keep doing exactly that — pairing careful analysis
> with reporting that genuinely helps people move faster — is what draws me to this role.

## ✉️ Cover-Letter — Concise & Direct
> I build supply-chain risk systems end-to-end. My recent pipeline scored 3,000 POs with anomaly
> detection and classification (Python, Scikit-learn), ranked 120 suppliers by risk, automated Power BI
> KPI alerts, and used cost-based thresholds to prioritize intervention on the riskiest orders. I'd bring
> that same outcome-focused approach to your team.

---

## 🎤 Interview talking points (STAR)
**Situation** — Procurement lacked early warning on which orders would arrive late or which suppliers were most fragile.
**Task** — Build a system to predict late deliveries, rank supplier risk, and prioritize intervention.
**Action** — Joined a 5-fact star schema; engineered supplier-scorecard, disruption-history and network-dependency features; trained Isolation Forest + Random Forest; built a composite risk score with a cost-based intervention threshold; shipped a Power BI model and dashboard.
**Result** — A prioritized watch-list, tiered escalation tied to SLAs, and a cost-minimizing operating point capturing ~97% of late deliveries.

**Q: Your model AUC is only ~0.53 — why?**
A: I was transparent that this *synthetic* dataset's label is essentially random vs. pre-delivery features — the only strong predictor (`delay_days`) is post-hoc leakage I deliberately excluded. That's the correct, honest call: a model that "cheats" with leakage would show fake-high accuracy and fail in production. On real data with genuine supplier/lead-time/disruption signal, the same pipeline produces real lift.

---

## 📌 Skills demonstrated
`Python` · `Scikit-learn` · `pandas` · `Feature Engineering` · `Anomaly Detection` · `Classification`
`Star-Schema Modeling` · `Power BI` · `Risk Scoring` · `Cost-Sensitive Learning` · `Data Visualization` · `KPI Alerting`
