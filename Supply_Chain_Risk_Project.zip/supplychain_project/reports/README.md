# 🏭 Supply Chain Risk — End-to-End Analytics Project

The same end-to-end workflow built for the fraud project, re-themed for **supply chain risk**.
Dataset: a star schema of **3,000 purchase orders, 120 suppliers, 200 disruption events** across
4 fiscal years (3 dimension + 5 fact tables).

> **Prediction target:** `on_time_delivery = N` → predict a **late / failed delivery** (28.4% late rate).

---

## 📊 Key Results

| Metric | Value |
|---|---|
| Purchase orders analyzed | 3,000 |
| Suppliers monitored | 120 |
| Disruption events | 200 |
| Late deliveries | 852 (28.4%) |
| Total disruption loss | $478.9M |
| High / Critical risk POs | 640 |
| Random Forest ROC-AUC | 0.53 *(see note)* |
| Isolation Forest ROC-AUC | 0.52 |

> **Honest modeling note:** in this *synthetic* dataset the late/on-time label is largely
> random with respect to pre-delivery features (the only strong signal, `delay_days`, is a
> post-hoc leakage feature excluded from training). So predictive AUC is modest (~0.53).
> On real operational data, supplier history, lead times and disruption signals carry genuine
> predictive value — the **pipeline, features, risk scoring and cost-based thresholds transfer directly.**

---

## 🔧 Pipeline Steps
1. **Load & clean** the star schema (dedupe, type-cast).
2. **Feature engineering** — join facts to dims; build supplier-risk signals (scorecard averages, disruption history, network dependency counts, sole-source/critical-path flags, lead times, tier, age) + order features.
3. **EDA** — 7 exploratory visualizations.
4. **Anomaly detection** — Isolation Forest (unsupervised risk signal).
5. **Classification** — Random Forest predicting late delivery (balanced class weights).
6. **Risk scoring** — composite `0.7×late_prob + 0.3×anomaly` → Low/Medium/High/Critical.
7. **Threshold tuning** — cost-based (late delivery $12k vs. intervention $600).
8. **Export & persist** — scored CSV, supplier ranking, Excel, PDF, dashboard, Power BI dataset, models.

---

## 📁 Deliverables

**Charts (`charts/`)** — 14 PNGs: delivery outcome, late-rate by category, disruptions by type & severity, loss by type, correlation heatmap, late trend, supplier risk band, confusion matrix, ROC, precision-recall, feature importance, risk-level distribution, cost curve, metric-vs-threshold.

**Data (`data/`)**
- `scored_purchase_orders.csv` — every PO with `late_probability`, `risk_score`, `risk_level`.
- `supplier_risk_ranking.csv` — suppliers ranked by average PO risk.
- `top_high_risk_pos.csv` — top 500 escalation queue.
- `supply_chain_analysis_report.xlsx` — multi-sheet workbook.
- `threshold_sweep.csv`, `alert_rules.json`, `metrics.json`, `dashboard_data.json`.

**Reports (`reports/`)** — `Supply_Chain_Risk_Report.pdf`, this `README.md`.

**Dashboard** — `supply_chain_dashboard.html` (interactive, self-contained, opens in any browser).

**Power BI (`powerbi/`)** — star-schema CSVs (fact_purchase_orders_scored, fact_disruptions, dim_suppliers/products/plants/risk_level, kpi_measures) + `DATA_MODEL.md` (relationships, DAX, visuals).

**Models (`models/`)** — `random_forest_late.joblib`, `isolation_forest.joblib`, `scaler.joblib`, `features.json`.

---

## 🗄️ SQL layer & Inventory bottlenecks (resume-gap closers)
- **`04_sql_analysis.py`** builds a queryable **DuckDB** database (`data/supply_chain.duckdb`) from all 8 CSVs and runs 5 analytical SQL queries → `data/sql_*.csv`. Queries saved in `sql/analysis_queries.sql`. This makes the *"SQL and Pandas"* claim literally true.
- **Inventory bottleneck analysis** added: 17 SKUs below reorder point, **9 High/Critical items understocked**, lowest cover just **1.8 days**. Charts 15–17 (days-of-stock, bottlenecks by plant, stock-vs-reorder scatter).

## 📊 Power BI (real DAX)
- `powerbi/MEASURES.dax` — **30+ production DAX measures** (delivery, risk, supplier, disruption, inventory, traffic-light KPI status).
- `powerbi/*.csv` — star-schema tables incl. `fact_inventory_buffer`.
- `powerbi/DATA_MODEL.md` — relationships + visual layout. Assemble the `.pbix` in Power BI Desktop in ~10 min.

> **Note on .pbix:** Power BI's binary `.pbix` can only be authored inside Power BI Desktop, which can't run in this environment. The package gives you everything to finish it instantly (data model + every DAX measure + step-by-step relationships).

## ▶️ Reproduce
```bash
pip install pandas numpy scikit-learn matplotlib seaborn openpyxl fpdf2 joblib duckdb
python 01_pipeline.py            # clean, EDA, models, scoring, exports
python 02_threshold_powerbi.py   # threshold tuning + Power BI + dashboard data
python 03_build_report.py        # PDF report
python 04_sql_analysis.py        # SQL layer (DuckDB) + inventory bottlenecks
```

**Tech stack:** Python · pandas · NumPy · Scikit-learn · matplotlib/seaborn · Power BI · SVG dashboard.
