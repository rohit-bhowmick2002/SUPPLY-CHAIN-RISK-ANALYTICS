-- q1_shipment_delays_by_supplier
SELECT s.supplier_name, s.category, s.tier,
       COUNT(*) AS total_orders,
       SUM(CASE WHEN po.on_time_delivery='N' THEN 1 ELSE 0 END) AS late_orders,
       ROUND(100.0*SUM(CASE WHEN po.on_time_delivery='N' THEN 1 ELSE 0 END)/COUNT(*),1) AS late_pct,
       ROUND(AVG(po.delay_days),1) AS avg_delay_days
FROM fact_purchase_orders po
JOIN dim_suppliers s ON po.supplier_id=s.supplier_id
GROUP BY 1,2,3
HAVING COUNT(*) >= 10
ORDER BY late_pct DESC
LIMIT 20;

-- q2_supplier_risk_overview
SELECT s.risk_band,
       COUNT(DISTINCT s.supplier_id) AS suppliers,
       ROUND(AVG(sc.composite_score),1) AS avg_scorecard,
       SUM(d.disruptions) AS total_disruptions,
       ROUND(SUM(d.loss)/1e6,1) AS total_loss_musd
FROM dim_suppliers s
LEFT JOIN (SELECT supplier_id, AVG(composite_score) composite_score FROM fact_supplier_scorecard GROUP BY 1) sc
       ON s.supplier_id=sc.supplier_id
LEFT JOIN (SELECT supplier_id, COUNT(*) disruptions, SUM(financial_loss_usd) loss FROM fact_disruptions GROUP BY 1) d
       ON s.supplier_id=d.supplier_id
GROUP BY 1
ORDER BY CASE s.risk_band WHEN 'High' THEN 3 WHEN 'Medium' THEN 2 ELSE 1 END DESC;

-- q3_inventory_bottlenecks
SELECT pl.plant_name, pr.product_name, pr.criticality,
       i.current_stock, i.reorder_point, i.safety_stock,
       ROUND(i.days_of_stock,1) AS days_of_stock,
       i.is_shortage_risk,
       ROUND(i.current_stock - i.reorder_point,0) AS stock_vs_reorder
FROM fact_inventory_buffer i
JOIN dim_plants pl  ON i.plant_id=pl.plant_id
JOIN dim_products pr ON i.product_id=pr.product_id
WHERE i.current_stock < i.reorder_point OR i.is_shortage_risk='Y'
ORDER BY days_of_stock ASC
LIMIT 25;

-- q4_disruption_impact
SELECT disruption_type, severity,
       COUNT(*) AS events,
       ROUND(SUM(financial_loss_usd)/1e6,2) AS loss_musd,
       ROUND(AVG(duration_days),0) AS avg_duration_days,
       SUM(CASE WHEN is_resolved='Y' THEN 1 ELSE 0 END) AS resolved
FROM fact_disruptions
GROUP BY 1,2
ORDER BY loss_musd DESC
LIMIT 20;

-- q5_plant_inventory_health
SELECT pl.plant_name, pl.country_name,
       COUNT(*) AS sku_lines,
       SUM(CASE WHEN i.is_shortage_risk='Y' THEN 1 ELSE 0 END) AS shortage_skus,
       SUM(CASE WHEN i.current_stock < i.reorder_point THEN 1 ELSE 0 END) AS below_reorder,
       ROUND(AVG(i.days_of_stock),1) AS avg_days_of_stock
FROM fact_inventory_buffer i
JOIN dim_plants pl ON i.plant_id=pl.plant_id
GROUP BY 1,2
ORDER BY below_reorder DESC, avg_days_of_stock ASC;

